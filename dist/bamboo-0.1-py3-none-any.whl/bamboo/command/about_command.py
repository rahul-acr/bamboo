from bamboo.utils.printing import print_bold


def run(**_):
    print_bold('Bamboo Backup 0.1')
    print('Developed by Rahul Saha (rahul.saha.c@gmail.com)')
    print('Github : github.com/rahul-acr')
